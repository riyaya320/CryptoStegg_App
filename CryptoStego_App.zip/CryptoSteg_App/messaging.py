"""
CryptoSteg - Enhanced Messaging System
Agent-to-agent secure messaging with steganographic images
"""

import os
import json
import uuid
import time
import shutil
from datetime import datetime
from werkzeug.utils import secure_filename

class MessagingSystem:
    """Enhanced messaging system for agent-to-agent communication"""
    
    def __init__(self):
        self.messages_dir = "messages"
        self.inbox_dir = "inbox"
        os.makedirs(self.messages_dir, exist_ok=True)
        os.makedirs(self.inbox_dir, exist_ok=True)
        self.message_db = {}
        self.load_messages()
    
    def send_message(self, sender, recipient, stego_image_path, message_id=None):
        """Send steganographic image to another agent"""
        # Import here to avoid circular imports
        from crypto import pki_manager
        
        # Validate recipient exists in PKI system
        if recipient not in pki_manager.users_db:
            return False, f"Agent {recipient} not found in system"
        
        # Check if recipient is revoked
        if recipient in pki_manager.crl:
            return False, f"Agent {recipient} access has been revoked"
        
        if message_id is None:
            message_id = str(uuid.uuid4())
        
        # Create message record
        message_data = {
            'id': message_id,
            'sender': sender,
            'recipient': recipient,
            'timestamp': datetime.now().isoformat(),
            'status': 'sent',
            'image_path': stego_image_path,
            'read': False,
            'original_filename': os.path.basename(stego_image_path)
        }
        
        # Store in sender's sent messages
        if sender not in self.message_db:
            self.message_db[sender] = {'sent': [], 'received': []}
        self.message_db[sender]['sent'].append(message_data)
        
        # Store in recipient's inbox
        if recipient not in self.message_db:
            self.message_db[recipient] = {'sent': [], 'received': []}
        
        recipient_message = message_data.copy()
        recipient_message['status'] = 'received'
        self.message_db[recipient]['received'].append(recipient_message)
        
        # Copy image to recipient's inbox with proper error handling
        try:
            recipient_image_path = os.path.join(self.inbox_dir, f"{recipient}_{message_id}.png")
            
            # Ensure inbox directory exists
            os.makedirs(self.inbox_dir, exist_ok=True)
            
            shutil.copy2(stego_image_path, recipient_image_path)
            
            # Update the recipient message with the new path
            self.message_db[recipient]['received'][-1]['image_path'] = recipient_image_path
            
        except Exception as e:
            print(f"Error copying image to inbox: {str(e)}")
            return False, f"Failed to deliver message: {str(e)}"
        
        self.save_messages()
        return True, message_id
    
    def get_inbox(self, username):
        """Get all received messages for a user"""
        if username not in self.message_db:
            return []
        # Sort by timestamp, newest first
        messages = self.message_db[username]['received']
        return sorted(messages, key=lambda x: x['timestamp'], reverse=True)
    
    def get_sent_messages(self, username):
        """Get all sent messages for a user"""
        if username not in self.message_db:
            return []
        # Sort by timestamp, newest first
        messages = self.message_db[username]['sent']
        return sorted(messages, key=lambda x: x['timestamp'], reverse=True)
    
    def mark_as_read(self, username, message_id):
        """Mark a message as read"""
        if username in self.message_db:
            for message in self.message_db[username]['received']:
                if message['id'] == message_id:
                    message['read'] = True
                    self.save_messages()
                    return True
        return False
    
    def get_message_by_id(self, username, message_id):
        """Get a specific message by ID"""
        if username in self.message_db:
            # Check received messages
            for message in self.message_db[username]['received']:
                if message['id'] == message_id:
                    return message
            # Check sent messages
            for message in self.message_db[username]['sent']:
                if message['id'] == message_id:
                    return message
        return None
    
    def get_message_image_path(self, username, message_id):
        """Get the image path for a specific message"""
        message = self.get_message_by_id(username, message_id)
        if message and 'image_path' in message:
            return message['image_path']
        return None
    
    def delete_message(self, username, message_id):
        """Delete a message from user's inbox or sent items"""
        if username not in self.message_db:
            return False
        
        # Check and remove from received messages
        received = self.message_db[username]['received']
        for i, message in enumerate(received):
            if message['id'] == message_id:
                # Clean up image file
                if os.path.exists(message['image_path']):
                    os.remove(message['image_path'])
                received.pop(i)
                self.save_messages()
                return True
        
        # Check and remove from sent messages
        sent = self.message_db[username]['sent']
        for i, message in enumerate(sent):
            if message['id'] == message_id:
                sent.pop(i)
                self.save_messages()
                return True
        
        return False
    
    def get_unread_count(self, username):
        """Get count of unread messages"""
        if username not in self.message_db:
            return 0
        return len([m for m in self.message_db[username]['received'] if not m['read']])
    
    def get_message_statistics(self, username):
        """Get messaging statistics for a user"""
        if username not in self.message_db:
            return {'sent': 0, 'received': 0, 'unread': 0}
        
        user_data = self.message_db[username]
        return {
            'sent': len(user_data.get('sent', [])),
            'received': len(user_data.get('received', [])),
            'unread': self.get_unread_count(username)
        }
    
    def save_messages(self):
        """Save message database to disk"""
        with open(os.path.join(self.messages_dir, 'messages.json'), 'w') as f:
            json.dump(self.message_db, f, indent=2)
    
    def load_messages(self):
        """Load message database from disk"""
        try:
            with open(os.path.join(self.messages_dir, 'messages.json'), 'r') as f:
                self.message_db = json.load(f)
        except FileNotFoundError:
            self.message_db = {}

# Global messaging instance
messaging_system = MessagingSystem()