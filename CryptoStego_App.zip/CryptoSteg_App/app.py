"""
CryptoSteg - Enhanced Main Flask Application
Advanced steganography tool with authentication and dashboard system
"""

import os
import uuid
import qrcode
from flask import Flask, render_template, request, jsonify, send_file, url_for, session, redirect
from werkzeug.utils import secure_filename
import io
import base64
from crypto import pki_manager
from enhanced_stego import enhanced_stego_engine
from auth import auth_manager
from messaging import messaging_system

app = Flask(__name__)
app.config['SECRET_KEY'] = 'cryptosteg_enhanced_secret_key_2024'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STEGO_FOLDER'] = 'static/stego_images'

# Create necessary directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['STEGO_FOLDER'], exist_ok=True)
os.makedirs('static', exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp'}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def require_auth(f):
    """Decorator to require authentication"""
    def decorated_function(*args, **kwargs):
        session_token = session.get('session_token')
        if not session_token:
            return redirect('/login')
        
        valid, message, username = auth_manager.validate_session(session_token)
        if not valid:
            session.clear()
            return redirect('/login')
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/')
def index():
    """Landing page - redirect based on authentication status"""
    session_token = session.get('session_token')
    if session_token:
        valid, message, username = auth_manager.validate_session(session_token)
        if valid:
            return redirect('/dashboard')
    return redirect('/login')

@app.route('/login')
def login_page():
    """Login page"""
    return render_template('login.html')

@app.route('/register')
def register_page():
    """Registration page"""
    return render_template('register.html')

@app.route('/dashboard')
@require_auth
def dashboard():
    """Main dashboard after authentication"""
    session_token = session.get('session_token')
    valid, message, username = auth_manager.validate_session(session_token)
    
    user_profile = auth_manager.get_user_profile(username)
    pki_stats = pki_manager.get_stats()
    
    return render_template('dashboard.html', 
                         username=username, 
                         user_profile=user_profile,
                         pki_stats=pki_stats)

@app.route('/operations')
@require_auth
def operations():
    """Steganography operations interface"""
    session_token = session.get('session_token')
    valid, message, username = auth_manager.validate_session(session_token)
    return render_template('operations.html', username=username)

@app.route('/profile')
@require_auth
def profile():
    """User profile page"""
    session_token = session.get('session_token')
    valid, message, username = auth_manager.validate_session(session_token)
    user_profile = auth_manager.get_user_profile(username)
    return render_template('profile.html', username=username, user_profile=user_profile)

@app.route('/api/login', methods=['POST'])
def api_login():
    """API endpoint for user login"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'success': False, 'message': 'Username and password required'})
        
        success, message, session_token = auth_manager.authenticate_user(username, password)
        
        if success:
            session['session_token'] = session_token
            session['username'] = username
            
            # Register with PKI if not already registered
            if username not in pki_manager.users_db:
                pki_success, pki_token = pki_manager.register_user(username)
                if pki_success:
                    session['pki_token'] = pki_token
            else:
                session['pki_token'] = pki_manager.users_db[username]['session_token']
            
            return jsonify({
                'success': True,
                'message': 'Authentication successful',
                'redirect': '/dashboard'
            })
        else:
            return jsonify({'success': False, 'message': message})
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Login failed: {str(e)}'})

@app.route('/api/register', methods=['POST'])
def api_register():
    """API endpoint for user registration"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        registration_code = data.get('registration_code', '').strip()
        email = data.get('email', '').strip()
        
        if not username or not password or not registration_code:
            return jsonify({'success': False, 'message': 'All fields required'})
        
        if len(username) < 3:
            return jsonify({'success': False, 'message': 'Username must be at least 3 characters'})
        
        success, message = auth_manager.register_user(username, password, registration_code, email)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Registration successful',
                'redirect': '/login'
            })
        else:
            return jsonify({'success': False, 'message': message})
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Registration failed: {str(e)}'})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """API endpoint for user logout"""
    session_token = session.get('session_token')
    if session_token:
        auth_manager.logout_user(session_token)
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/send_message', methods=['POST'])
@require_auth
def send_message():
    """Process message sending with steganography and QR generation"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = auth_manager.validate_session(session_token)
        
        message = request.form.get('message')
        recipient = request.form.get('recipient', '').strip()
        send_method = request.form.get('send_method', 'manual')
        
        if not message:
            return jsonify({'success': False, 'message': 'Message required'})
        
        # Validate recipient for direct messaging
        if send_method == 'direct':
            if not recipient:
                return jsonify({'success': False, 'message': 'Recipient required for direct messaging'})
            
            if recipient not in pki_manager.users_db:
                return jsonify({'success': False, 'message': f'Agent "{recipient}" not found'})
            
            if recipient in pki_manager.crl:
                return jsonify({'success': False, 'message': f'Agent "{recipient}" access has been revoked'})
        
        # Handle file upload
        if 'image' not in request.files:
            return jsonify({'success': False, 'message': 'No image uploaded'})
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No image selected'})
        
        if not allowed_file(file.filename):
            return jsonify({'success': False, 'message': 'Invalid file type. Use PNG, JPG, JPEG, or BMP'})
        
        # Save uploaded image
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(upload_path)
        
        # Encrypt message
        encrypted_payload = pki_manager.encrypt_message(message, username)
        
        # Embed encrypted message in image
        success, result = enhanced_stego_engine.embed_message(upload_path, encrypted_payload, username)
        
        if not success:
            os.remove(upload_path)
            return jsonify({'success': False, 'message': result})
        
        # Save stego image
        stego_filename = f"stego_{unique_filename}"
        stego_path = os.path.join(app.config['STEGO_FOLDER'], stego_filename)
        result.save(stego_path)
        
        # Generate QR code with dynamic URL and session token
        pki_token = session.get('pki_token')
        
        # Get the server's IP address for mobile access
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            stego_url = f"http://{local_ip}:5000/stego/{stego_filename}?token={pki_token}"
        except:
            stego_url = url_for('get_stego_image', filename=stego_filename, token=pki_token, _external=True)
        
        # Create QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(stego_url)
        qr.make(fit=True)
        
        # Generate QR code image
        qr_img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert QR to base64 for display
        qr_buffer = io.BytesIO()
        qr_img.save(qr_buffer, format='PNG')
        qr_base64 = base64.b64encode(qr_buffer.getvalue()).decode()
        
        # Clean up original upload
        os.remove(upload_path)
        
        # Handle direct messaging
        if send_method == 'direct' and recipient:
            message_success, message_id = messaging_system.send_message(
                username, recipient, stego_path
            )
            if message_success:
                return jsonify({
                    'success': True,
                    'message': f'Message delivered to Agent {recipient}',
                    'qr_code': f"data:image/png;base64,{qr_base64}",
                    'stego_url': stego_url,
                    'delivery_status': 'delivered',
                    'message_id': message_id
                })
            else:
                return jsonify({
                    'success': False,
                    'message': f'Failed to deliver message to Agent {recipient}'
                })
        
        return jsonify({
            'success': True,
            'message': 'Message embedded successfully',
            'qr_code': f"data:image/png;base64,{qr_base64}",
            'stego_url': stego_url,
            'delivery_status': 'manual'
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Processing failed: {str(e)}'})

@app.route('/stego/<filename>')
def get_stego_image(filename):
    """Serve stego image with token validation"""
    try:
        token = request.args.get('token')
        if not token:
            return "Access denied: No token provided", 403
        
        # Validate token
        success, username = pki_manager.authenticate_user(token)
        if not success:
            return f"Access denied: {username}", 403
        
        stego_path = os.path.join(app.config['STEGO_FOLDER'], filename)
        if not os.path.exists(stego_path):
            return "Image not found", 404
        
        return send_file(stego_path)
        
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/api/extract_message', methods=['POST'])
@require_auth
def extract_message():
    """Extract hidden message from uploaded stego image"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = auth_manager.validate_session(session_token)
        
        message_id = request.form.get('message_id')  # For inbox messages
        
        # Handle inbox message extraction
        if message_id:
            message = messaging_system.get_message_by_id(username, message_id)
            if not message:
                return jsonify({'success': False, 'message': 'Message not found'})
            
            stego_path = message['image_path']
            if not os.path.exists(stego_path):
                return jsonify({'success': False, 'message': 'Message image not found'})
            
            # Mark as read
            messaging_system.mark_as_read(username, message_id)
            
            try:
                # Extract message using enhanced steganography engine
                success, result = enhanced_stego_engine.extract_message(stego_path, username)
                
                if not success:
                    return jsonify({'success': False, 'message': f'Extraction failed: {result}'})
                
                # Decrypt message and verify signature
                decrypt_success, decrypted_message, sender = pki_manager.decrypt_message(result)
                
                if not decrypt_success:
                    return jsonify({'success': False, 'message': f'Decryption failed: {decrypted_message}'})
                
                return jsonify({
                    'success': True,
                    'message': 'Message extracted successfully',
                    'decrypted_message': decrypted_message,
                    'sender': sender,
                    'message_id': message_id
                })
                
            except Exception as e:
                return jsonify({'success': False, 'message': f'Processing error: {str(e)}'})
            
        else:
            # Handle manual file upload
            if 'stego_image' not in request.files:
                return jsonify({'success': False, 'message': 'No image uploaded'})
            
            file = request.files['stego_image']
            if file.filename == '':
                return jsonify({'success': False, 'message': 'No image selected'})
            
            # Save uploaded stego image temporarily
            temp_filename = f"temp_{uuid.uuid4()}_{secure_filename(file.filename)}"
            stego_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_filename)
            file.save(stego_path)
            
            try:
                # Extract message
                success, result = enhanced_stego_engine.extract_message(stego_path, username)
                
                if not success:
                    return jsonify({'success': False, 'message': result})
                
                # Decrypt message and verify signature
                decrypt_success, decrypted_message, sender = pki_manager.decrypt_message(result)
                
                if not decrypt_success:
                    return jsonify({'success': False, 'message': decrypted_message})
                
                return jsonify({
                    'success': True,
                    'message': 'Message extracted successfully',
                    'decrypted_message': decrypted_message,
                    'sender': sender
                })
                
            finally:
                # Clean up temp file
                if os.path.exists(stego_path):
                    os.remove(stego_path)
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Extraction failed: {str(e)}'})

@app.route('/api/get_agents', methods=['GET'])
@require_auth
def get_agents():
    """Get list of all registered agents"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = auth_manager.validate_session(session_token)
        
        # Get all agents except current user and revoked agents
        all_agents = []
        for agent_name, agent_data in pki_manager.users_db.items():
            if agent_name != username and not agent_data.get('revoked', False):
                all_agents.append(agent_name)
        
        return jsonify({
            'success': True,
            'agents': all_agents
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/get_inbox', methods=['GET'])
@require_auth
def get_inbox():
    """Get user's inbox messages"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = auth_manager.validate_session(session_token)
        
        inbox = messaging_system.get_inbox(username)
        unread_count = messaging_system.get_unread_count(username)
        
        return jsonify({
            'success': True,
            'inbox': inbox,
            'unread_count': unread_count
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/delete_message', methods=['POST'])
@require_auth
def delete_message():
    """Delete a message from user's inbox or sent items"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = auth_manager.validate_session(session_token)
        
        data = request.get_json()
        message_id = data.get('message_id')
        
        if not message_id:
            return jsonify({'success': False, 'message': 'Message ID required'})
        
        success = messaging_system.delete_message(username, message_id)
        
        if success:
            return jsonify({'success': True, 'message': 'Message deleted successfully'})
        else:
            return jsonify({'success': False, 'message': 'Message not found or already deleted'})
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Delete failed: {str(e)}'})

@app.route('/api/get_registration_codes')
def get_registration_codes():
    """Get available registration codes (for display purposes)"""
    codes = auth_manager.get_registration_codes()
    # Only show codes with remaining uses
    available_codes = [code for code in codes if code['remaining'] > 0]
    return jsonify({'codes': available_codes})

@app.route('/stats')
def get_stats():
    """Get application statistics"""
    pki_stats = pki_manager.get_stats()
    auth_stats = {
        'total_users': len(auth_manager.auth_db),
        'active_sessions': len(auth_manager.active_sessions),
        'registration_codes': len(auth_manager.registration_codes)
    }
    return jsonify({
        'pki_stats': pki_stats,
        'auth_stats': auth_stats
    })

if __name__ == '__main__':
    print("🔐 CryptoSteg - Enhanced Steganography Tool")
    print("📡 Main application running on http://localhost:5000")
    
    # Get and display the actual IP address
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"📱 Mobile access available at http://{local_ip}:5000")
        print(f"🌐 Network IP: {local_ip}")
    except Exception as e:
        print(f"⚠️  Could not determine IP address: {e}")
    
    print("🔧 Admin panel available at http://localhost:5001/admin")
    
    # Display registration codes
    print("\n🔑 Available Registration Codes:")
    codes = auth_manager.get_registration_codes()
    for code in codes[:3]:  # Show first 3 codes
        print(f"   {code['code']} ({code['remaining']} uses remaining)")
    
    # Try to run with explicit network binding
    try:
        app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
    except Exception as e:
        print(f"❌ Failed to start server: {e}")
        print("🔧 Trying alternative configuration...")
        app.run(debug=True, host='127.0.0.1', port=5000, threaded=True)