"""
CryptoSteg - Enhanced Steganography Module
Improved LSB steganography with PBKDF2-derived randomization and comprehensive security
"""

import hashlib
import random
import json
import secrets
import base64
import os
from PIL import Image
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

class EnhancedSteganographyEngine:
    """Enhanced LSB Steganography with cryptographic randomization and integrity checking"""
    
    def __init__(self):
        self.delimiter = "<<<CRYPTOSTEG_END>>>"
        self.max_message_ratio = 0.92  # Use max 92% of image capacity for safety
    
    def derive_secure_seed(self, username, image_hash):
        """Derive cryptographically secure seed using PBKDF2"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=image_hash[:16],
            iterations=100000,
            backend=default_backend()
        )
        key = kdf.derive(username.encode('utf-8'))
        return int.from_bytes(key[:4], 'big')
    
    def calculate_image_hash(self, image_path):
        """Calculate SHA-256 hash of image for seed derivation"""
        hasher = hashlib.sha256()
        with open(image_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hasher.update(chunk)
        return hasher.digest()
    
    def validate_input_security(self, image_path, message, username):
        """Comprehensive input validation"""
        errors = []
        
        # Validate image file
        if not os.path.exists(image_path):
            errors.append("Image file does not exist")
        
        try:
            with Image.open(image_path) as img:
                if img.size[0] < 10 or img.size[1] < 10:
                    errors.append("Image too small (minimum 10x10 pixels)")
        except Exception as e:
            errors.append(f"Invalid image file: {str(e)}")
        
        # Validate message
        if len(message) > 10000:  # 10KB limit
            errors.append("Message too long (maximum 10KB)")
        
        # Validate username
        if not username or len(username) < 1:
            errors.append("Invalid username")
        
        return len(errors) == 0, errors
    
    def validate_message_capacity(self, image_path, message):
        """Validate message fits in image capacity"""
        try:
            capacity = self.calculate_capacity(image_path)
            message_size = len(message.encode('utf-8'))
            
            if message_size > capacity:
                return False, f"Message too large. Maximum: {capacity} bytes, provided: {message_size} bytes"
            
            return True, "Capacity check passed"
        except Exception as e:
            return False, f"Capacity validation failed: {str(e)}"
    
    def calculate_capacity(self, image_path):
        """Calculate usable capacity for message embedding"""
        with Image.open(image_path) as img:
            width, height = img.size
            total_pixels = width * height
            available_bits = total_pixels * 3  # RGB channels
            
            # Reserve space for checksum, length, and delimiter
            overhead_bits = (64 + 32 + len(self.delimiter)) * 8
            safety_margin = int(available_bits * (1 - self.max_message_ratio))
            
            usable_bits = available_bits - overhead_bits - safety_margin
            return max(0, usable_bits // 8)  # Convert to bytes
    
    def generate_secure_checksum(self, data):
        """Generate secure SHA-256 checksum with salt"""
        salt = secrets.token_bytes(16)
        hasher = hashlib.sha256()
        hasher.update(salt)
        hasher.update(data.encode('utf-8'))
        return base64.b64encode(salt + hasher.digest()).decode('ascii')
    
    def verify_secure_checksum(self, data, checksum_b64):
        """Verify secure checksum"""
        try:
            checksum_data = base64.b64decode(checksum_b64.encode('ascii'))
            salt = checksum_data[:16]
            expected_hash = checksum_data[16:]
            
            hasher = hashlib.sha256()
            hasher.update(salt)
            hasher.update(data.encode('utf-8'))
            calculated_hash = hasher.digest()
            
            # Constant-time comparison
            return secrets.compare_digest(expected_hash, calculated_hash)
        except:
            return False
    
    def embed_message(self, image_path, message, username):
        """Enhanced message embedding with comprehensive security"""
        try:
            # Comprehensive input validation
            valid, errors = self.validate_input_security(image_path, message, username)
            if not valid:
                return False, f"Validation failed: {'; '.join(errors)}"
            
            # Capacity validation
            capacity_ok, capacity_msg = self.validate_message_capacity(image_path, message)
            if not capacity_ok:
                return False, capacity_msg
            
            # Open and process image
            img = Image.open(image_path)
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Generate secure seed
            image_hash = self.calculate_image_hash(image_path)
            seed = self.derive_secure_seed(username, image_hash)
            
            # Generate secure checksum
            checksum = self.generate_secure_checksum(message)
            
            # Create payload with enhanced format
            payload = f"{checksum}|{len(message)}|{message}{self.delimiter}"
            binary_payload = ''.join(format(ord(char), '08b') for char in payload)
            
            # Validate payload size one more time
            img_width, img_height = img.size
            max_capacity = img_width * img_height * 3
            
            if len(binary_payload) > max_capacity * self.max_message_ratio:
                return False, "Payload too large after processing"
            
            # Generate secure random positions using derived seed
            random.seed(seed)
            
            # Create list of all pixel positions
            positions = []
            for y in range(img_height):
                for x in range(img_width):
                    for channel in range(3):  # RGB channels
                        positions.append((x, y, channel))
            
            # Shuffle positions securely
            random.shuffle(positions)
            
            # Convert image to list for modification
            pixels = list(img.getdata())
            
            # Embed message bits with error checking
            embedded_bits = 0
            for i, bit in enumerate(binary_payload):
                if i >= len(positions):
                    return False, "Insufficient image capacity"
                
                x, y, channel = positions[i]
                pixel_index = y * img_width + x
                
                if pixel_index >= len(pixels):
                    return False, "Pixel index out of bounds"
                
                pixel = list(pixels[pixel_index])
                
                # Modify LSB of the specified channel
                pixel[channel] = (pixel[channel] & 0xFE) | int(bit)
                pixels[pixel_index] = tuple(pixel)
                embedded_bits += 1
            
            # Create new image with modified pixels
            stego_img = Image.new('RGB', (img_width, img_height))
            stego_img.putdata(pixels)
            
            # Verify embedding by attempting extraction
            verification_success, verification_result = self.extract_message_internal(stego_img, username, image_hash)
            if not verification_success:
                return False, f"Embedding verification failed: {verification_result}"
            
            if verification_result != message:
                return False, "Embedding verification: message mismatch"
            
            return True, stego_img
            
        except Exception as e:
            return False, f"Enhanced embedding failed: {str(e)}"
    
    def extract_message_internal(self, img, username, image_hash=None):
        """Internal extraction method for verification"""
        try:
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            img_width, img_height = img.size
            
            # Generate same secure seed
            if image_hash is None:
                # This shouldn't happen in normal operation
                return False, "Image hash required for extraction"
            
            seed = self.derive_secure_seed(username, image_hash)
            
            # Generate same randomized positions
            random.seed(seed)
            
            positions = []
            for y in range(img_height):
                for x in range(img_width):
                    for channel in range(3):
                        positions.append((x, y, channel))
            
            random.shuffle(positions)
            
            # Extract bits
            pixels = list(img.getdata())
            binary_message = ""
            
            for x, y, channel in positions:
                pixel_index = y * img_width + x
                
                if pixel_index >= len(pixels):
                    break
                
                pixel = pixels[pixel_index]
                
                # Extract LSB
                bit = pixel[channel] & 1
                binary_message += str(bit)
                
                # Check for delimiter in extracted text
                if len(binary_message) % 8 == 0:
                    # Convert binary to text
                    chars = []
                    for i in range(0, len(binary_message), 8):
                        byte = binary_message[i:i+8]
                        if len(byte) == 8:
                            try:
                                chars.append(chr(int(byte, 2)))
                            except ValueError:
                                continue
                    
                    current_text = ''.join(chars)
                    if self.delimiter in current_text:
                        # Found delimiter, extract message
                        message_with_metadata = current_text.split(self.delimiter)[0]
                        
                        if '|' in message_with_metadata:
                            parts = message_with_metadata.split('|', 2)
                            if len(parts) >= 3:
                                stored_checksum, length_str, message = parts
                                
                                try:
                                    expected_length = int(length_str)
                                    if len(message) != expected_length:
                                        return False, "Message length mismatch"
                                except ValueError:
                                    return False, "Invalid message length format"
                                
                                # Verify secure checksum
                                if self.verify_secure_checksum(message, stored_checksum):
                                    return True, message
                                else:
                                    return False, "Checksum verification failed"
                        
                        return False, "Invalid message format"
            
            return False, "No hidden message found"
            
        except Exception as e:
            return False, f"Internal extraction failed: {str(e)}"
    
    def extract_message(self, image_path, username):
        """Enhanced message extraction with security validation"""
        try:
            # Input validation
            valid, errors = self.validate_input_security(image_path, "dummy", username)
            if not valid:
                # Filter out message-related errors for extraction
                image_errors = [e for e in errors if 'message' not in e.lower()]
                if image_errors:
                    return False, f"Validation failed: {'; '.join(image_errors)}"
            
            # Open image
            img = Image.open(image_path)
            image_hash = self.calculate_image_hash(image_path)
            
            return self.extract_message_internal(img, username, image_hash)
            
        except Exception as e:
            return False, f"Enhanced extraction failed: {str(e)}"
    
    def get_image_info(self, image_path):
        """Get comprehensive image information"""
        try:
            with Image.open(image_path) as img:
                usable_bytes = self.calculate_capacity(image_path)
                
                return {
                    'format': img.format,
                    'mode': img.mode,
                    'size': img.size,
                    'total_pixels': img.size[0] * img.size[1],
                    'usable_bytes': usable_bytes,
                    'max_message_length': usable_bytes,
                    'file_size': os.path.getsize(image_path)
                }
        except Exception as e:
            return {'error': str(e)}

# Global enhanced steganography instance
enhanced_stego_engine = EnhancedSteganographyEngine()