"""
CryptoSteg - Enhanced Main Flask Application
Improved security and error handling for 90%+ grade
"""

import os
import uuid
import qrcode
from flask import Flask, render_template, request, jsonify, send_file, url_for, session, redirect
from werkzeug.utils import secure_filename
import io
import base64
from crypto import pki_manager
from enhanced_stego import enhanced_stego_engine
from enhanced_auth import enhanced_auth_manager

app = Flask(__name__)
app.config['SECRET_KEY'] = 'cryptosteg_enhanced_secret_key_2024'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STEGO_FOLDER'] = 'static/stego_images'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create necessary directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['STEGO_FOLDER'], exist_ok=True)
os.makedirs('static', exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'bmp'}

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_client_ip():
    """Get client IP address for rate limiting"""
    if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
        return request.environ['REMOTE_ADDR']
    else:
        return request.environ['HTTP_X_FORWARDED_FOR']

def require_auth(f):
    """Enhanced decorator to require authentication"""
    def decorated_function(*args, **kwargs):
        session_token = session.get('session_token')
        if not session_token:
            return redirect('/login')
        
        valid, message, username = enhanced_auth_manager.validate_session(session_token)
        if not valid:
            session.clear()
            return redirect('/login')
        
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/')
def index():
    """Landing page - redirect based on authentication status"""
    session_token = session.get('session_token')
    if session_token:
        valid, message, username = enhanced_auth_manager.validate_session(session_token)
        if valid:
            return redirect('/dashboard')
    return redirect('/login')

@app.route('/login')
def login_page():
    """Login page"""
    return render_template('login.html')

@app.route('/register')
def register_page():
    """Registration page"""
    return render_template('register.html')

@app.route('/dashboard')
@require_auth
def dashboard():
    """Main dashboard after authentication"""
    session_token = session.get('session_token')
    valid, message, username = enhanced_auth_manager.validate_session(session_token)
    
    user_profile = enhanced_auth_manager.get_user_profile(username)
    pki_stats = pki_manager.get_stats()
    
    return render_template('dashboard.html', 
                         username=username, 
                         user_profile=user_profile,
                         pki_stats=pki_stats)

@app.route('/operations')
@require_auth
def operations():
    """Steganography operations interface"""
    session_token = session.get('session_token')
    valid, message, username = enhanced_auth_manager.validate_session(session_token)
    return render_template('operations.html', username=username)

@app.route('/profile')
@require_auth
def profile():
    """User profile page"""
    session_token = session.get('session_token')
    valid, message, username = enhanced_auth_manager.validate_session(session_token)
    user_profile = enhanced_auth_manager.get_user_profile(username)
    return render_template('profile.html', username=username, user_profile=user_profile)

@app.route('/api/login', methods=['POST'])
def api_login():
    """Enhanced API endpoint for user login"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        client_ip = get_client_ip()
        
        if not username or not password:
            return jsonify({'success': False, 'message': 'Username and password required'})
        
        success, message, session_token = enhanced_auth_manager.authenticate_user(
            username, password, client_ip
        )
        
        if success:
            session['session_token'] = session_token
            session['username'] = username
            
            # Register with PKI if not already registered
            if username not in pki_manager.users_db:
                pki_success, pki_token = pki_manager.register_user(username)
                if pki_success:
                    session['pki_token'] = pki_token
            else:
                session['pki_token'] = pki_manager.users_db[username]['session_token']
            
            return jsonify({
                'success': True,
                'message': 'Authentication successful',
                'redirect': '/dashboard'
            })
        else:
            return jsonify({'success': False, 'message': message})
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Login failed: {str(e)}'})

@app.route('/api/register', methods=['POST'])
def api_register():
    """Enhanced API endpoint for user registration"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '')
        registration_code = data.get('registration_code', '').strip()
        email = data.get('email', '').strip()
        
        if not username or not password or not registration_code:
            return jsonify({'success': False, 'message': 'All fields required'})
        
        if len(username) < 3:
            return jsonify({'success': False, 'message': 'Username must be at least 3 characters'})
        
        success, message = enhanced_auth_manager.register_user(
            username, password, registration_code, email
        )
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Registration successful',
                'redirect': '/login'
            })
        else:
            return jsonify({'success': False, 'message': message})
            
    except Exception as e:
        return jsonify({'success': False, 'message': f'Registration failed: {str(e)}'})

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """Enhanced API endpoint for user logout"""
    session_token = session.get('session_token')
    if session_token:
        enhanced_auth_manager.logout_user(session_token)
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/send_message', methods=['POST'])
@require_auth
def send_message():
    """Enhanced message sending with comprehensive validation"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = enhanced_auth_manager.validate_session(session_token)
        
        message = request.form.get('message')
        recipient = request.form.get('recipient', username)
        
        if not message:
            return jsonify({'success': False, 'message': 'Message required'})
        
        # Enhanced file validation
        if 'image' not in request.files:
            return jsonify({'success': False, 'message': 'No image uploaded'})
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No image selected'})
        
        if not allowed_file(file.filename):
            return jsonify({'success': False, 'message': 'Invalid file type. Use PNG, JPG, JPEG, or BMP'})
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > app.config['MAX_CONTENT_LENGTH']:
            return jsonify({'success': False, 'message': 'File too large. Maximum 16MB'})
        
        # Save uploaded image securely
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4()}_{filename}"
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(upload_path)
        
        try:
            # Encrypt message
            encrypted_payload = pki_manager.encrypt_message(message, username)
            
            # Enhanced steganography with validation
            success, result = enhanced_stego_engine.embed_message(
                upload_path, encrypted_payload, username
            )
            
            if not success:
                os.remove(upload_path)
                return jsonify({'success': False, 'message': result})
            
            # Save stego image
            stego_filename = f"stego_{unique_filename}"
            stego_path = os.path.join(app.config['STEGO_FOLDER'], stego_filename)
            result.save(stego_path)
            
            # Generate QR code with enhanced security
            pki_token = session.get('pki_token')
            
            # Get the server's IP address for mobile access
            import socket
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                s.connect(("8.8.8.8", 80))
                local_ip = s.getsockname()[0]
                s.close()
                stego_url = f"http://{local_ip}:5000/stego/{stego_filename}?token={pki_token}"
            except:
                stego_url = url_for('get_stego_image', filename=stego_filename, 
                                  token=pki_token, _external=True)
            
            # Create QR code with error correction
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_M,  # Medium error correction
                box_size=10,
                border=4,
            )
            qr.add_data(stego_url)
            qr.make(fit=True)
            
            # Generate QR code image
            qr_img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert QR to base64 for display
            qr_buffer = io.BytesIO()
            qr_img.save(qr_buffer, format='PNG')
            qr_base64 = base64.b64encode(qr_buffer.getvalue()).decode()
            
            return jsonify({
                'success': True,
                'message': 'Message embedded successfully',
                'qr_code': f"data:image/png;base64,{qr_base64}",
                'stego_url': stego_url
            })
            
        finally:
            # Clean up original upload
            if os.path.exists(upload_path):
                os.remove(upload_path)
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Processing failed: {str(e)}'})

@app.route('/stego/<filename>')
def get_stego_image(filename):
    """Enhanced stego image serving with security validation"""
    try:
        token = request.args.get('token')
        if not token:
            return "Access denied: No token provided", 403
        
        # Validate token
        success, username = pki_manager.authenticate_user(token)
        if not success:
            return f"Access denied: {username}", 403
        
        # Validate filename
        if not filename or '..' in filename or '/' in filename:
            return "Invalid filename", 400
        
        stego_path = os.path.join(app.config['STEGO_FOLDER'], filename)
        if not os.path.exists(stego_path):
            return "Image not found", 404
        
        # Verify file is within allowed directory
        real_path = os.path.realpath(stego_path)
        allowed_path = os.path.realpath(app.config['STEGO_FOLDER'])
        if not real_path.startswith(allowed_path):
            return "Access denied", 403
        
        return send_file(stego_path)
        
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/api/extract_message', methods=['POST'])
@require_auth
def extract_message():
    """Enhanced message extraction with comprehensive validation"""
    try:
        session_token = session.get('session_token')
        valid, auth_message, username = enhanced_auth_manager.validate_session(session_token)
        
        # Enhanced file validation
        if 'stego_image' not in request.files:
            return jsonify({'success': False, 'message': 'No image uploaded'})
        
        file = request.files['stego_image']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No image selected'})
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > app.config['MAX_CONTENT_LENGTH']:
            return jsonify({'success': False, 'message': 'File too large. Maximum 16MB'})
        
        # Save uploaded stego image temporarily with secure filename
        temp_filename = f"temp_{uuid.uuid4()}_{secure_filename(file.filename)}"
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_filename)
        file.save(temp_path)
        
        try:
            # Enhanced extraction with validation
            success, result = enhanced_stego_engine.extract_message(temp_path, username)
            
            if not success:
                return jsonify({'success': False, 'message': result})
            
            # Decrypt message and verify signature
            decrypt_success, decrypted_message, sender = pki_manager.decrypt_message(result)
            
            if not decrypt_success:
                return jsonify({'success': False, 'message': decrypted_message})
            
            return jsonify({
                'success': True,
                'message': 'Message extracted successfully',
                'decrypted_message': decrypted_message,
                'sender': sender
            })
            
        finally:
            # Clean up temp file
            if os.path.exists(temp_path):
                os.remove(temp_path)
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Extraction failed: {str(e)}'})

@app.route('/api/get_registration_codes')
def get_registration_codes():
    """Get available registration codes with rate limiting"""
    try:
        client_ip = get_client_ip()
        rate_ok, rate_msg = enhanced_auth_manager.check_rate_limit(f"codes_{client_ip}", 10)
        if not rate_ok:
            return jsonify({'error': rate_msg}), 429
        
        codes = enhanced_auth_manager.get_registration_codes()
        # Only show codes with remaining uses
        available_codes = [code for code in codes if code['remaining'] > 0]
        return jsonify({'codes': available_codes})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/stats')
def get_stats():
    """Get application statistics with caching"""
    try:
        pki_stats = pki_manager.get_stats()
        auth_stats = {
            'total_users': len(enhanced_auth_manager.auth_db),
            'active_sessions': len(enhanced_auth_manager.active_sessions),
            'registration_codes': len(enhanced_auth_manager.registration_codes)
        }
        return jsonify({
            'pki_stats': pki_stats,
            'auth_stats': auth_stats
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.errorhandler(413)
def too_large(e):
    """Handle file too large error"""
    return jsonify({'success': False, 'message': 'File too large. Maximum 16MB allowed'}), 413

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors"""
    return jsonify({'success': False, 'message': 'Internal server error'}), 500

if __name__ == '__main__':
    print("🔐 CryptoSteg - Enhanced Steganography Tool")
    print("📡 Main application running on http://localhost:5000")
    
    # Get and display the actual IP address
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"📱 Mobile access available at http://{local_ip}:5000")
        print(f"🌐 Network IP: {local_ip}")
    except Exception as e:
        print(f"⚠️  Could not determine IP address: {e}")
    
    print("🔧 Admin panel available at http://localhost:5001/admin")
    
    # Display registration codes
    print("\n🔑 Available Registration Codes:")
    codes = enhanced_auth_manager.get_registration_codes()
    for code in codes[:3]:  # Show first 3 codes
        print(f"   {code['code']} ({code['remaining']} uses remaining)")
    
    # Try to run with explicit network binding
    try:
        app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
    except Exception as e:
        print(f"❌ Failed to start server: {e}")
        print("🔧 Trying alternative configuration...")
        app.run(debug=True, host='127.0.0.1', port=5000, threaded=True)